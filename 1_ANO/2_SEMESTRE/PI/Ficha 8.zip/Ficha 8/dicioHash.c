#include "listaPal.h"
#include <stdio.h>
#include <stdlib.h>
#include "dicionario.h"

#define HSIZE 1000

struct d {
    Palavras tab [HSIZE];
};

unsigned int hash (char *pal, int s){
    // http://www.cse.yorku.ca/~oz/hash.html
    unsigned int r;
    for (r=5381; *pal; pal++) 
      r = (r*33 + *pal); 
    return (r % s);
}

Dicionario initDic () {
    int i;
    Dicionario d = malloc (sizeof (struct d));
    for (i=0; i<HSIZE; i++) 
    	d->tab[i] = NULL;
    return d;
}

int acrescenta (Dicionario d, char *pal){
	int pos; int r;
    pos = hash (pal, HSIZE);
    //printf ("%u\n", pos);
    r = acrescenta_Ini (d->tab + pos,pal);
	
    return r;
}

char *maisFreq (Dicionario d, int *c){
    int i, mf, aux;
    char *pmfreq, *tmp;
    mf = 0; pmfreq=NULL;
    for (i=0; i<HSIZE; i++) {
    	tmp = palMaisFreq (d->tab[i], &aux);
    	if (aux>mf) { mf=aux; pmfreq = tmp;}
    }
    *c = mf;
    return pmfreq;
}

void listaDicionario (Dicionario d){
    int i;
    for (i=0; i<HSIZE; i++)
    	listaPalavras (d->tab[i]);
}
