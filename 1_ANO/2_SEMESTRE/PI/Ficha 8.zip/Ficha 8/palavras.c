#include <ctype.h>
#include <string.h>

void removetrailingpunct(char *p){
    int i=strlen (p);
    
    while (i--)
        if (ispunct(p[i])) p[i]='\0';
        else break;
    
}

void toUpper (char *p) {
	for (;*p;p++)
		*p = toupper(*p);
}