#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "listaPal.h"

int acrescenta_Fim (Palavras *d, char *pal){
    // Quando a palavra n�o existe, acrescenta-a ao fim da lista
    while (*d != NULL && (strcmp ((*d)->palavra,pal) != 0)) 
         d = &((*d)->prox);
    if (*d == NULL) {
        *d = malloc (sizeof (struct entrada));
        (*d)->palavra = strdup (pal);
        (*d)->ocorr = 1;
        (*d)->prox=NULL;
    } else (*d)->ocorr++;

    return (*d)->ocorr;
}

int acrescenta_Ord (Palavras *d, char *pal){
    // inser��o ordenada (alfab�tica)
    Palavras nova;
    int r = 0;

    while (*d && strcmp ((*d)->palavra,pal) < 0)
        d = &((*d)->prox);
    if (*d != NULL && strcmp ((*d)->palavra,pal) == 0)
       (*d)->ocorr ++ ;
    else if ((nova = malloc (sizeof (struct entrada)))) {
        nova->palavra = strdup (pal);
        nova->ocorr = 1;
        nova->prox = *d;
        *d = nova;
    } else r = 1;
    return r;
}

int acrescenta_Ini (Palavras *d, char *pal){
    // a c�lula onde est� esta palavra passa sempre para o inicio da lista
    Palavras *inicio = d, nova;
    int r = 0;

    while (*d != NULL && strcmp ((*d)->palavra, pal) != 0)
        d = &((*d)->prox);
    if (*d != NULL) { // palavra j� existe
        (*d)->ocorr ++; // actualiza ocorr�ncias
        nova = *d;
        (*d) = (*d)->prox; // remove-a da lista
    } else  // palavra n�o existe
         if ((nova = malloc (sizeof (struct entrada)))) {
             nova->palavra = strdup (pal);
             nova->ocorr = 1;
         } else r = 1;
    if (r == 0) {
        // ligar a palavra actual ao inicio da lista
        nova->prox = *inicio;
        *inicio = nova;
    }
    return r;
}

char *palMaisFreq (Palavras p, int *c){
    char *r = NULL; int m=0;
    if (p!=NULL) {
        r = p->palavra; m = p->ocorr;
        for (p=p->prox; p!=NULL; p=p->prox)
            if (p->ocorr > m) {
                r = p->palavra; m = p->ocorr;
            }
    }
    *c=m;
    return r;
}

void listaPalavras (Palavras p){
    for (;p!=NULL; p=p->prox)
        printf ("%s ocorre %d vezes\n", p->palavra, p->ocorr);
}
