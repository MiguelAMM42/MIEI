#ifndef _listaPal_h
#define _listaPal_h

typedef struct entrada{
	char *palavra;
	int ocorr;
	struct entrada *prox;
} *Palavras;

int acrescenta_Fim (Palavras *d, char *pal);
int acrescenta_Ord (Palavras *d, char *pal);
int acrescenta_Ini (Palavras *d, char *pal);
char *palMaisFreq  (Palavras p, int *c);
void listaPalavras (Palavras p);

#endif


