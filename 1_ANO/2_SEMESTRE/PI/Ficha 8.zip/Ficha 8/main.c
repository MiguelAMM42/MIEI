#include <stdio.h>
#include "dicionario.h"
#include "palavras.h"

int main() {
    Dicionario d; int c=0; char *p;
    char pal[50];

    d = initDic ();
    
    while (scanf ("%s", pal) == 1) {
        removetrailingpunct (pal);
        toUpper (pal);
        if (*pal) acrescenta (d,pal);
    }
    
    p = maisFreq (d, &c);
    printf ("Palavra mais frequente (%d): %s\n", c, p);
    return 0;
}
