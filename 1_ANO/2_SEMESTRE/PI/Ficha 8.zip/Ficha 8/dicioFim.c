
#include <stdio.h>
#include <stdlib.h>
#include "listaPal.h"
#include "dicionario.h"

struct d {
	Palavras lista;
};

Dicionario initDic (){
	Dicionario d = malloc (sizeof (struct d));
    d->lista = NULL; 
    return d;  
}

int acrescenta (Dicionario d, char *pal) {
    return (acrescenta_Fim (&(d->lista),pal));
}

char *maisFreq (Dicionario d, int *c){
    return (palMaisFreq (d->lista,c));
}

void listaDicionario (Dicionario d){
     listaPalavras (d->lista);
}
