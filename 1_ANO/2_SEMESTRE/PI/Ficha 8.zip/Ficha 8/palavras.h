#ifndef _palavras_h
#define _palavras_h

void removetrailingpunct(char *);
void toUpper (char *);

#endif

