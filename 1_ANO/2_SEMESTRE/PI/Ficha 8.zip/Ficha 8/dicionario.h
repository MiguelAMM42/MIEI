typedef struct d* Dicionario;

Dicionario initDic ();

int acrescenta (Dicionario d, char *pal);

char *maisFreq (Dicionario d, int *c);

void listaDicionario (Dicionario d);
